function Header() {
    return (
      <>
        <div className="header" style={{ backgroundImage: "url(/public/bushi-logo.png)" }}>
          <div className="header-content p-4">
          </div>
        </div>
      </>
    );
  }
  
  export default Header;
  