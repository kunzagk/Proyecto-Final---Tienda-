const mockUser = {
  email: 'nacho@gmail.com',
  password: 'hola123',
  // Otros datos del usuario
};

export default mockUser;
